<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\{
    UserDashboardController,
    AdminDashboardController,
    TeamDashboardController,
    TaskController,
    WalletController,
    ServiceController,
    PaymentController
};

Route::get('/', function () {
    return redirect('/login');
});

Auth::routes(['verify' => true]);

Route::middleware(['auth', 'verified'])->group(function () {
    Route::middleware('role:user')->group(function () {
        Route::get('/user/dashboard', [UserDashboardController::class, 'index'])->name('user.dashboard');
        Route::get('/tasks', [TaskController::class, 'index'])->name('tasks.index');
        Route::post('/tasks', [TaskController::class, 'store'])->name('tasks.store');
        Route::get('/wallet', [WalletController::class, 'index'])->name('wallet.index');
        Route::post('/wallet/fund', [WalletController::class, 'fund'])->name('wallet.fund');
        Route::get('/services', [ServiceController::class, 'index'])->name('services.index');
        Route::post('/payment/redirect', [PaymentController::class, 'redirectToGateway'])->name('payment.redirect');
        Route::get('/payment/callback', [PaymentController::class, 'paymentCallback'])->name('payment.callback');
    });

    Route::middleware('role:admin')->group(function () {
        Route::get('/admin/dashboard', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
    });

    Route::middleware('role:team')->group(function () {
        Route::get('/team/dashboard', [TeamDashboardController::class, 'index'])->name('team.dashboard');
    });
});