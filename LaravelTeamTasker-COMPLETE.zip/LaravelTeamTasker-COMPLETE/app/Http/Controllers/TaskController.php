<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TaskController extends Controller
{
    public function index()
    {
        return view('user.tasks.index');
    }

    public function store(Request $request)
    {
        // Store task logic (dummy for demo)
        return redirect()->back()->with('success', 'Task created.');
    }
}