<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function redirectToGateway(Request $request)
    {
        $amount = $request->input('amount');
        $ref = 'MOCK-' . uniqid();
        return view('mockpay.redirect', compact('ref', 'amount'));
    }

    public function paymentCallback()
    {
        return redirect()->route('wallet.index')->with('success', 'Payment successful');
    }
}