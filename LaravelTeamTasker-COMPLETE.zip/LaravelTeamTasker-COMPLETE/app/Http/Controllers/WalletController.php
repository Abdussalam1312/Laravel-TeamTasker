<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class WalletController extends Controller
{
    public function index()
    {
        $wallet = (object)['balance' => 2000];
        return view('user.wallet.index', compact('wallet'));
    }

    public function fund(Request $request)
    {
        return back()->with('success', 'Wallet funded.');
    }
}