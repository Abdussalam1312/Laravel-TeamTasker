<!DOCTYPE html>
<html>
<head><title>Laravel TeamTasker</title></head>
<body>
@auth
<p>Logged in as {{ Auth::user()->email }} | 
    <form method="POST" action="{{ route('logout') }}" style="display:inline;">
        @csrf <button type="submit">Logout</button>
    </form></p>
@endauth
<hr>
@yield('content')
</body>
</html>