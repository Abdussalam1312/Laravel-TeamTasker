<!DOCTYPE html>
<html>
<head>
    <title>@yield('title', 'Laravel TeamTasker')</title>
</head>
<body>
    <div class="container">
        <h1>@yield('heading')</h1>
        @yield('content')
    </div>
</body>
</html>