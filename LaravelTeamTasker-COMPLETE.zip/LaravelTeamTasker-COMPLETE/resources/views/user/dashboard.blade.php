@extends('layouts.app')

@section('title', 'User Dashboard')
@section('heading', 'Welcome, User')
@section('content')
    <p>This is your dashboard.</p>
@endsection