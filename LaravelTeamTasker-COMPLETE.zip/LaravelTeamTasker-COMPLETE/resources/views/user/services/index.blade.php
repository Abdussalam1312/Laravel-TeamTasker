@extends('layouts.app')

@section('title', 'Services')
@section('heading', 'Available Services')
@section('content')
    <p>Here are the available services.</p>
@endsection