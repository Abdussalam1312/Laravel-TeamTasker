@extends('layouts.app')

@section('title', 'Wallet')
@section('heading', 'Your Wallet')
@section('content')
    <p>Your wallet balance will appear here.</p>
@endsection