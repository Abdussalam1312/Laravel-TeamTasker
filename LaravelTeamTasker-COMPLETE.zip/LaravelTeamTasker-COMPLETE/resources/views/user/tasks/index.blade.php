@extends('layouts.app')

@section('title', 'Tasks')
@section('heading', 'Your Tasks')
@section('content')
    <p>Here are your tasks.</p>
@endsection