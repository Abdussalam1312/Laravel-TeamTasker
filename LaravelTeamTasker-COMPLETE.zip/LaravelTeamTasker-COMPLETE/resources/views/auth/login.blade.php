@extends('layouts.app')

@section('title', 'Login')
@section('heading', 'Login')
@section('content')
    <form method="POST" action="{{ route('login') }}">
        @csrf
        <input type="email" name="email" required placeholder="Email"><br>
        <input type="password" name="password" required placeholder="Password"><br>
        <button type="submit">Login</button>
    </form>
@endsection