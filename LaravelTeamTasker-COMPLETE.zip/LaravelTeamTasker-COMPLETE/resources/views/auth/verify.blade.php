@extends('layouts.app')

@section('title', 'Verify Email')
@section('heading', 'Email Verification Required')
@section('content')
    <p>Please verify your email before accessing the dashboard.</p>
@endsection