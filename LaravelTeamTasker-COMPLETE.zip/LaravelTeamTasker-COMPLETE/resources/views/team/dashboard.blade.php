@extends('layouts.app')

@section('title', 'Team Dashboard')
@section('heading', 'Welcome, Team Member')
@section('content')
    <p>This is the team dashboard.</p>
@endsection