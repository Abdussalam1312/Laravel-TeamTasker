@extends('layouts.app')

@section('title', 'Redirecting to Payment')
@section('heading', 'Payment Gateway')
@section('content')
    <p>Redirecting to mock ASPFIY with amount: {{ $amount }} and ref: {{ $ref }}</p>
    <a href="{{ route('payment.callback') }}">Simulate Payment Success</a>
@endsection