@extends('layouts.app')

@section('title', 'Admin Dashboard')
@section('heading', 'Welcome, Admin')
@section('content')
    <p>This is the admin dashboard.</p>
@endsection