# Laravel TeamTasker

This is a Laravel 10 project titled **"Laravel TeamTasker by Abdussalam A Sirajo (CEO MUA Developer)"**, designed for user, team, and admin management with tasks, services, and wallet features.

## Setup Instructions

1. Extract the ZIP and upload to your hosting (e.g., Truehost).
2. Run `composer install` to generate the `vendor/` folder.
3. Copy `.env.example` to `.env` and update your DB, mail, and app settings.
4. Run `php artisan key:generate`.
5. Create a database and import `database/teamtasker.sql`.
6. Run migrations if needed: `php artisan migrate`.
7. Start the app via local server or your web host.

## Default Routes

- `/login`, `/register`, `/dashboard`
- `/user/dashboard`, `/admin/dashboard`, `/team/dashboard`
- `/user/tasks`, `/user/wallet`, `/user/services`